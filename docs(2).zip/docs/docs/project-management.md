# Project Management
Updated Date: 24/09/2021  
Authors:Nguyen Vu, Alex Mak, Neel Kumar, Rain Wu, Ziying Li, Shubham Bajoria
## Story Map
![STORY MAP](https://user-images.githubusercontent.com/56895462/134756273-b4188714-2fca-4ed8-9aaf-c1f062c5f73d.jpg)

## Project Plan
### Sprint 1  
**Due: 25/09/2021**

| **Rubric Description** | **Task To-Do** | **Assigned To** | **Date To Complete By** |
| --- | --- | --- | --- | 
| Glossary | Requirements Document | Ziying Li, Rain Wu | 09/20/2021 |
| User Stories | Requirements Document | Nguyen Vu, Alex Mak, Neel Kumar, Rain Wu, Ziying Li, Shubham Bajoria | 09/20/2021 | 
| Executive Summary + Similar Products + Technical Resources | Requirements Document | Nguyen Vu | 09/20/2021 | 
| Team Canvas | Management Document | Nguyen Vu, Alex Mak, Neel Kumar, Rain Wu, Ziying Li, Shubham Bajoria | 09/22/2021 | 
| Component Diagram | Software Document | Nguyen Vu | 09/22/2021 | 
| Interaction scenarios | Software Document | Shubham Bajoria | 09/22/2021 | 
| Storymap | Management Document | Alex Mak, Shubham Bajoria | 09/23/2021 | 
| Architecture Diagram | Software Document| Nguyen Vu | 09/23/2021 | 
| Low-fidelity UI | Software Document | Neel Kumar, Rain Wu, Ziying Li | 09/24/2021 | 
| Backlog & Project Plan| Management Document | Alex Mak, Nguyen Vu, Ziying Li, Neel Kumar| 09/24/2021 | 
| Deployment | Groundwork | Neel Kumar | 09/25/2021 |

### Sprint 2  
**Due: 16/10/2021**

| **Rubric Description** | **Task To-Do** | **Assigned To** | **Date To Complete By** |
| --- | --- | --- | --- | 
| Frontend Codebase | Skeleton | Neel Kumar| 09/30/2021 |
| Backend Codebase | Skeleton | Nguyen Vu | 09/28/2021 |
| CI pipeline | Setup | Nguyen Wu | 10/07/2021 | 
| Docker | Setup | Nguyen Wu | 09/30/2021 | 
| Deployment setup | Setup | | 09/30/2021 | 
| API Documentation | Document | Nguyen Vu | 10/09/2021 | 
| Authentication(BE) | US 2.09 US 2.10 US 2.11 US 2.12 US 4.10 US 4.11 US 4.12 US 4.13 unit tests| Nguyen Vu | 10/02/2021 | 
| Organization(BE) | US 2.01 unit tests | Nguyen Vu | 10/02/2021 | 
| Login | US 2.12 US 3.04 US 4.13| Neel Kumar | 10/07/2021 | 
| Profile(BE) | US 2.07 US 2.08 US 4.09 unit tests| Nguyen Vu  | 10/12/2021 | 
| SignUp | US 2.10 US 2.11 US 3.05 US 4.11 US 4.12 | Ziying Li | 10/07/2021 | 
| HomePage( Signout) | US 2.09 US 3.03 US 4.10 | Neel Kumar | 10/09/2021 | 
| Admin generate and view access code | US 2.01 | Ziying Li | 10/09/2021 | 
| Create an assessment | US 1.01 US 2.02 US 4.01| Rain Wu | 10/13/2021 | 
| Finish and submit assessment | US 2.03 US 4.02 US 4.03 US 4.04 | Shubham Bajoria, Rain Wu | 10/13/2021 |

### Sprint 3  
**Due: 13/11/2021**

| **Rubric Description** | **Task To-Do** | **Assigned To** | **Date To Complete By** |
| --- | --- | --- | --- | 
| Edit profile | US 2.08 US 4.09 | Nguyen Vu, Rain Wu, Alex Mak | 10/23/2021 | 
| View results | US 2.04 US 3.02| Neel Kumar, Ziying Li, Shubham Bajoria | 10/30/2021 | 
| Export result | US 2.05 US 3.02 | Nguyen Vu, Rain Wu, Alex Mak | 10/30/2021 | 
| Admin view member list | US 2.06 | Neel Kumar, Ziying Li, Shubham Bajoria | 11/05/2021 | 
| EFCL admin view organization list | US 3.01 | Neel Kumar, Ziying Li, Shubham Bajoria | 11/05/2021 | 

### Sprint 4  
**Due: 24/11/2021**

| **Rubric Description** | **Task To-Do** | **Assigned To** | **Date To Complete By** |
| --- | --- | --- | --- | 
| Give Score | US 1.02 | --- | 11/2021 | 
| Board member see score | US 4.06 | --- | 11/2021 | 
| Board member get Score | US 4.05 | --- | 11/2021 | 
| Get feedback | US 4.08 | --- | 11/2021 | 
| EFCL admin Edit question | US 3.06 | --- | 11/2021 |

## Team Canvas

![Team Canvas](https://user-images.githubusercontent.com/44443467/134787121-7a858499-16fc-4d8c-b7e2-e3597b0d5dd7.png)

## Scrum roles

### Product Manager
| **Sprint 1** | **Sprint 2** | **Sprint 3** | **Sprint 4** |
| --- | --- | --- | --- | 
| Neel Kumar | Neel Kumar | Neel Kumar | Neel Kumar | 

### Scrum Master
| **Sprint 1** | **Sprint 2** | **Sprint 3** | **Sprint 4** |
| --- | --- | --- | --- | 
| Ziying Li | Ziying Li | Nguyen Vu | Nguyen Vu | 
