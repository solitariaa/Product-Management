# Test Documentation

## Test Suite



* **CI**: Continuous Integration Workflow. A built-in tool for GitHub. CI ensures the reliability of the code changes and code updates by carrying out the build, test, and package processes.
    * Test environment: ubuntu-latest.
    * Test database: postgreSQL.
    * Test objects: Django unit tests (manage.py test) and React tests (npm test).
    * Test Setup and Steps (in CI.yml):
        * Push and pull from main branch (line 3 - 7)
        * Build environment (line 10 - 16)
        * Setup postgres database (line 18 - 27)
        * Setup python (line 30 - 34)
        * Setup database adapter and install required models (line 35 - 41)
        * Make migration and migrate for the database (line 42 - 47)
        * Install ChromeDriver (line 48 - 58)
        * Setup Node for FE (line 59 - 62)
        * Run frontend React tests (line 62 - 60)
        * Run backend Django tests (line 72 - 79)
* **Django Unit Test** (unittest model which is built-in to the python library): We use Django REST framework to develop backend, then Django Unit Test becomes the first choice for testing backend. The Django Unit Test mainly tests our current APIs in the backend and all the tests are Automated.
    * 33 Tests associated with Django Unit Test:
        * OrganizationAssessmentTest (level:unit test)
            * Create accounts for a member and admin separately, then create an assessment template for them. 
            * Expected behaviour: Test reports OK (http 200 and blank assessment be saved in the database).
        * AssessmentDetailTest ((level: unit test)
            * Create accounts and assessment for a member and admin separately, then check the details of the assessment.
            *  Expected behaviour: Test reports OK (http 200 and assessment details corresponding to input data)
        * SaveResponseAndSubmitAssessmentTest (level: unit test)
            * Create accounts and assessments for a member and admin separately, then input answers and submit.
            *  Expected behaviour: Test reports OK (answers are saved in the database, get the right score and update the organization's average score)
        * AdminSignUpTest (level: unit test)
            * Sign up as a new admin.
            *  Expected behaviour: Test reports OK (http 200, new admin account and new organization. Not expected and invalid input)
        * MemberSignUpTest (level: unit test)
            * Sign up as a new member.
            *  Expected behaviour:Test reports OK (http 200, succeed sign up with given organization id)
        * LoginTest (level: unit test)
            * Login with existing and non-existing user information separately.
            *  Expected behaviour: Test reports OK (http 200 if account exists) and Bad Request (400 if account does not exist)
        * LogoutTest (level: unit test)
            * Logout as a user. 
            * Expected behaviour: Test reports OK (http 200 and token is destroyed)
        * ViewProfileTest (level: unit test)
            * Login as an admin and member, go to the corresponding profile and edit the profile. Admin should be able to see members’ profiles who belong to his organization.
            * Expected behaviour: Test reports OK (http 200 for get profiles, member edits own profiles and admin edits his member’s profile). Tests reports Access Denied (Expected 401 with wrong token .Expected 404 with invalid actions).
        * AdminViewMembersTest (level: unit test)
            * Login as Admin, go to the members’ list.
            * Expected behaviour: Test reports OK (http 200 if succeed and http 401 if members try to get the member list).
        * AdminGetIDTest (level: unit test)
            * Login as admin, share the organization id to members.
            * Expected behaviour: Test reports OK (http 200 if members successfully get the id).
        * ViewOrganizationTest (level: unit test)
            * Login as admin and member separately and try to view and edit org profile.
            * Expected behaviour: Test reports OK (200 if members view the org profile and admin view/edit the org profile). Test reports Bad Request ( 401 if members want to edit the org profile).
        * OrganizationListTest (level: unit test)
            * Login as efcl admin, view the organization lists. 
            * Expected behaviour: Test reports OK (200 if efcl admin gets the list successfully. Moreover, data on the list should be corresponding to the input organization data).
        * OrganizationMembersTest (level: unit test)
            * Login as efcl admin, check the members of one organization.
            * Expected behaviours: Test reports OK (http 200 if succeed. Members’ counting should be the same as input).
    * Deviations:
        None. All the tests passed.

* JEST:  jest is a JavaScript testing framework maintained by Facebook, we choose jest because it does not require a lot of configuration for first time users of a testing framework. Moreover, jest can support unit tests for React (FE).
    * Tests associated with Django Unit Test:
        * FillInTheBlankQuestion.test (level: unit test):
            * Check whether the question body matches the title of the question.
            * Expected behavior: Test reports pass.
        * FrequencyQuestion.test (level: unit test):
            * Check whether the number of choices matches what it should be, whether the question body matches the title of the question, check whether the choices label matches the choices.
            * Expected behavior: Test reports pass.
        * MultipleChoiceQuestion.test (level: unit test):
            * Check whether the number of choices matches what it should be, whether the question body matches the title of the question.
            * Expected behavior: Test reports pass.
        * MultipleSelectionQuestion.test (level: unit test):
            * Check whether the number of choices matches what it should be, whether the question body matches the title of the question.
            * Expected behavior: Test reports pass.
        * YesNoUnsureQuestion.test (level: unit test):
            * Check whether the number of choices matches what it should be, whether the question body matches the title of the question, check whether the choices label matches the choices.
            * Expected behavior: Test reports pass.
    * Deviation:
        * All the tests passed



* Selenium: Selenium is a free, open source automated testing framework used to validate web applications in browsers like Chrome, Firefox, and Internet Edge. Selenium can be used in python to create Selenium test cases. We use Selenium to test how our applications will run automatically based on the test scripts we wrote. We use Selenium to do end-to-end tests.
    * Tests associated with Selenium:
        * test01_EFCLAdminCreateAccount (level: end-to-end test)
            * Check whether the EFCL admin account can be created automatically.
            * Expected behaviour: EFCL admin account is created successfully.
        * test02_AdminCreateAccount (level: end-to-end test)
            * Check whether an administrator account for an organization can be created automatically.
            * Expected behavior: an administrator account is created successfully.
        * test03_LoginAndLogout (level: end-to-end test)
            * Check whether an account can be logged in with valid credentials, then logout automatically.
            * Expected behavior: The account will be first logged in, then logged out back to the app’s starting page.
        * test04_AdminStartAssessment (level: end-to-end test)
            * Check whether an administrator can login to his/her account, start an assessment, and submit answers in the assessment automatically. 
            * Expected behavior: 
                * The administrator will be able to login his/her account.
                * The administrator will initiate an assessment after log in.
                * The administrator will select one answer and skips to the next question, and then go back to the dashboard
                * The administrator will revisit the assessment and try to resubmit a question.
        * test05_EditProfile (level: end-to-end test)
            * Check whether an account can edit its own profile automatically.
            * Expected behavior: 
                * The account will be logged in using valid credentials, then it will change the first name of the account’s profile from ‘firstname’ to ‘admin2’.
    * Deviation:
        * All the tests passed.

**Acceptance Test Checklist**



* DUT = Django Unit Test
* MT = Manual test
* GU = Give Up  This test is abandoned, as the corresponding US or functionality is abandoned as per Client’s request.
* ST = Selenium test
* JT = JEST unit test
<table>
  <tr>
   <td>
User Story
   </td>
   <td>Acceptance Test
   </td>
   <td>Test Suite
   </td>
  </tr>
  <tr>
   <td>US 1.01
   </td>
   <td>Test to ensure that there are 2 types of assessment.
   </td>
   <td>DUT, MT, JT
   </td>
  </tr>
  <tr>
   <td>US 1.01
   </td>
   <td>Check similarity of the 2 type assessment.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 1.02
   </td>
   <td>The organizational admin's solutions are successfully saved.
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 1.02
   </td>
   <td>Members can get a score based on the organization admin’s solution.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 2.01
   </td>
   <td>Admin can see the organization uuid on the dashboard (auto generated).
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 2.01
   </td>
   <td>Admin copy the code to clipboard, check whether it's the same as origin.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.02
   </td>
   <td>Admin can click on the assessment.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.02
   </td>
   <td>Admin can do the assessment.
   </td>
   <td>MT, JT, ST
   </td>
  </tr>
  <tr>
   <td>US 2.02
   </td>
   <td>Admin can check whether his/her is in the assessment page or not.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.03
   </td>
   <td>Admin can hit submit after done. 
   </td>
   <td>MT, DUT
   </td>
  </tr>
  <tr>
   <td>US 2.03
   </td>
   <td>Admin should see the review of their responses after submission.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.03
   </td>
   <td>All of the answers are saved as a prototype to the database.
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 2.04
   </td>
   <td>Admin can see the average score of the organization.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.04
   </td>
   <td>Admin can see the list of members.
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 2.05
   </td>
   <td>Admin should be able to export the results.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.05
   </td>
   <td>The exported file should be a readable csv. file
   </td>
   <td>GU
   </td>
  </tr>
  <tr>
   <td>US 2.06
   </td>
   <td>Admin should be able to view all the members in the list (under the org).
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.06
   </td>
   <td>Each entry on the member list is clickable.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.07
   </td>
   <td>Admin can click on a member to be redirected to the profile(fully info).
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 2.08
   </td>
   <td>Make sure the admin account can be edited (with a button).
   </td>
   <td>MT, ST
   </td>
  </tr>
  <tr>
   <td>US 2.08
   </td>
   <td>New data is updated in the database.
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 2.09
   </td>
   <td>Admin can log out and back to the user sign in page.(account stop)
   </td>
   <td>MT, DUT
   </td>
  </tr>
  <tr>
   <td>US 2.10
   </td>
   <td>Admin can create org and check the org info. 
   </td>
   <td>MT, DUT, ST
   </td>
  </tr>
  <tr>
   <td>US 2.11
   </td>
   <td>Admin can sign up with appropriate input (or error with invalid info).
   </td>
   <td>MT, DUT
   </td>
  </tr>
  <tr>
   <td>US 2.11
   </td>
   <td>After the admin signs up he can go back to the sign in page.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 2.12
   </td>
   <td>Admin can sign in with correct info, then enter the homepage.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 2.13
   </td>
   <td>Admin can edit assessment.
   </td>
   <td>GU
   </td>
  </tr>
  <tr>
   <td>US 3.01
   </td>
   <td>EFCL-Admin should be able to see the list of all organizations registered.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 3.02
   </td>
   <td>EFCL-Admin should see each organization’s result (in a list of orgs).
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 3.03
   </td>
   <td>EFCL-Admin can logout and back to the sign in page. (account stop)
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 3.04
   </td>
   <td>EFCL-Admin can login with correct info and go to the homepage.
   </td>
   <td>DUT, MT, ST
   </td>
  </tr>
  <tr>
   <td>US 3.05
   </td>
   <td>EFCL-Admin can sign up with valid info, then go to the sign in page.
   </td>
   <td>DUT, MT, ST
   </td>
  </tr>
  <tr>
   <td>US 3.06
   </td>
   <td>EFCL-Admin can edit the questions for all orgs.
   </td>
   <td>GU
   </td>
  </tr>
  <tr>
   <td>US 4.01
   </td>
   <td>Members cannot see the assessment until the admin finishes it.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 4.01
   </td>
   <td>Members can start assessment and go to the assessment page.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.01
   </td>
   <td>Members should finish assessment in a limited time.
   </td>
   <td>GU
   </td>
  </tr>
  <tr>
   <td>US 4.02
   </td>
   <td>Members can choose/write the answer and submit the assessment.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.03
   </td>
   <td>Members can view the review of their responses.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.04
   </td>
   <td>Members can finish the assessment and go back to the homepage, data is saved in the database.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.05
   </td>
   <td>The member's assessment is graded based on the admin's answer.
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 4.06
   </td>
   <td>Members see their own score and the average score of the organization.
   </td>
   <td>MT, DUT
   </td>
  </tr>
  <tr>
   <td>US 4.07
   </td>
   <td>Members can quit the assessment.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.07
   </td>
   <td>Members can continue with the previous answer.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 4.08
   </td>
   <td>Board members should get feedback based on their own scores
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 4.09
   </td>
   <td>Members can edit his profile with valid info. New data is saved in db.
   </td>
   <td>MT, DUT
   </td>
  </tr>
  <tr>
   <td>US 4.09
   </td>
   <td>Members can view their own profile to ensure the new changes.
   </td>
   <td>MT
   </td>
  </tr>
  <tr>
   <td>US 4.10
   </td>
   <td>Members can logout with a button and back to the sign in page.
   </td>
   <td>DUT, MT, ST
   </td>
  </tr>
  <tr>
   <td>US 4.11
   </td>
   <td>Members can sign up with a given org id. 
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.11
   </td>
   <td>Members can go to the account creation page.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.12
   </td>
   <td>Members can sign up with valid info and go to the log-in page.
   </td>
   <td>DUT, MT
   </td>
  </tr>
  <tr>
   <td>US 4.12
   </td>
   <td>Members' info is saved in the database.
   </td>
   <td>DUT
   </td>
  </tr>
  <tr>
   <td>US 4.13
   </td>
   <td>Members can log in with correct info and be redirected to the homepage.
   </td>
   <td>DUT, MT
   </td>
  </tr>
</table>


	
