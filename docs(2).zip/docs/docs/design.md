# Software Design
Updated Date: 24/09/2021  
Authors: Ziying Li, Nguyen Vu, Shubham Bajoria, Neel Kumar

## Architecture/Component Diagram
![Architecture Dia](https://user-images.githubusercontent.com/56895462/137204177-479e35cb-01a9-435e-bfd3-3aabe2e52392.png)

- Django interacts with PostgreSQL database using Models User, Organization and Assessment and exports APIs using Rest Framework.

- React frontend sends HTTP Requests and retrieves HTTP Responses using axios, then displays data on components. Router is used to navigate to pages.

## UML Class Diagram
![UML](https://user-images.githubusercontent.com/44443467/137605676-43166cbc-c9e5-4044-89f1-a4af9e7b4170.png)

- The UML diagram describes data flow in the application. This includes data input on the front end, any handling by APIs, and data returned to the back end.
 

## Sequence Diagram
![Sequence diagram](https://user-images.githubusercontent.com/44443467/137605679-33818e08-b2ef-4d01-978b-0cbc0cb2f6ed.png)

- The sequence diagram describes core interactions between the user, the application and the database; in this case, the interactions for logging into the system and taking an assessment.


## Low-Fidelity User interface
![Low-Fidelity](https://user-images.githubusercontent.com/44443467/134786832-cc707b55-e42f-4af2-b7d3-1e6d61bef905.png)

- The low-fidelity UI diagram gives an early 'feel' for the application; it visually describes the general layout and user interaction flow.

