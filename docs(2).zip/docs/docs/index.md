# Project Requirements
Updated Date: 24/09/2021  
Authors: Nguyen Vu, Alex Mak, Neel Kumar, Rain Wu, Ziying Li, Shubham Bajoria

# Project Requirements

## Executive summary

EFCL has always been limited to using a paper-based method to assess the financial proficiency of volunteer board members in community associations. Now, with the help of the EFCL Financial Proficiency Assessment Tool, all of the assessments can go digital, and performing a survey is a mere matter of sharing the questionnaire and getting an overview of responses in one sitting. The executive team, the treasurers, and the board members no longer need to schedule a meeting to go over the assessments together. Instead, respondents can respond immediately, and the data is collated together automatically. The survey conductors can also be benefitted in getting access to real-time statistics of the surveys and perform advanced analysis on them. This application enables the managers to keep track of the assessed volunteers, as well as the financial information needed for research. Likewise, associations’ volunteers are also provided with assessment score reports to understand their current financial management proficiency and therefore, access and implement enhanced processes and procedures.

## Project glossary

 - **Result**: There will be two different results one can see. One is an individual's assessment result and the other is their organization's overall score. Results can be exported by admin as a chart of aggregated results.
 
 - **Admin**: A manager of the Web app or EFCL admin, they can view and manage treasurers and board members’ assessments results. EFCL Admin can also choose to export the results when needed.
 
 - **Treasurer**:  A treasurer or an organizational admin can take the survey made available for them by the EFCL admin, and see the overall results of their organziation after their organziation members submitted their assessment.

- **Board member**: A board member takes the survey made available for them by their organziation admin (who is different from the treasurers), and they can also see their own results after submitting their own assessment.

- **Assessment**: A kind of online surveys that assess the volunteers’ financial proficiency. The assessment questions would be the same for both organziation admin and the members. However, the assessments completed by board members are graded based on admin's responses to the assessment.

## User stories

### I. Server Admin
### US 1.01 - Two types of assessment
> **As** a Server Admin, **I want** to have 2 different types of assessment, **so that** I can have one done by the organizational admin and the other for members.

> **Acceptance Tests**

> 1. Test to ensure that there are 2 types of assessment
> 2. Even though they are the pretty much the same, but the options to questions are quite different.

### US 1.02 - Grade members' assessments
>**As** a Server Admin, **I want** to grade members' admin based on their organizational admin's assessment, **so that** I can give out the scores to them.

> **Acceptance Tests**

> 1. The organizational admin's solutions are saved in database for comparing with other assessments' results
> 2. The member's assessment is then compared with the solutions and there would be score given to each question after testing.


### II. ORGANIZATIONAL ADMIN
### US 2.01 - Admin can see the organization’s access code.
> **As** an admin, **I want** to view my organization’s unique code in the dashboard, **so that** I can share the code with my members.

> **Acceptance Tests**

> 1. Admin can see the organization code generated from uuid on the dashboard.
> 2. Admin can copy the code to clipboard. Test whether the copied code is the same as where the code was copied.

### US 2.02 - Admin can start the assessment.
> **As** an Admin, **I want** to start the assessment, **so that** I can set up the marking scheme for my organization’s assessment.

> **Acceptance Tests**
> 
> 1. Admin can click on the assessment.
> 2. Admin can do the assessment.
> 3. Admin can check whether his/her is in the assessment page or not.


### US 2.03 - Admin can finish the assessment.
> **As** an Admin, **I want** to finish the assessment I created, **so that** organizational assessment can be rolled out for other members.

> **Acceptance Tests**
> 
> 1. Admin can hit submit after done.
> 1.1. Error message if any of required fields was left blank. 
> 2. Once the assessment is submitted, admin should see the review of their responses.
> 3. All of the answers are saved as a prototype to the database.
 
	
### US 2.04 - Admin view the results
> **As** an Admin, **I want** to view the overview assessment results of my organization, know who are involved, and who have already done, **so that** I can understand the overall financial proficiency of members in my organization.
> 
> **Acceptance Tests**

> 1. Admin can see the average score of the organization. (maybe marks distribution also)
> 2. Admin can see the list of members.
> 3. Admin can see who has been done among the list.
> 4. For testing, admin should see update in terms of average score, member list and the ones who completed the assessments, when more assessments are submitted.

### US 2.05 - Admin export results
> **As** an Admin, **I want** to export the results , **so that** I can get the results and handle the data.

> **Acceptance Tests**

> 1. Admin should be able to export the results.
> 2. The exported file should be a readable csv. file
> 3. Admin should be able to view the exported file.

### US 2.06 - Admin view the members’ accounts list
> **As** an admin, **I want** to view my own organization’s accounts list, **so that** I can select a specific account in that list, and keep track of my organization members.

> **Acceptance Tests**

> 1. Admin should be able to view the accounts list.
> 2. The list should show all the members registered under the organization.
> 3. Each entry is clickable.
> 4. For testing, the members’ accounts list should not be empty.

### US 2.07 - Admin can view a member's profile.
> **As** an admin, **I want** to view the profile of an account within my organization, **so that** I can know more about my members in my organization.

> **Acceptance Tests**

> 1. Admin can click on a member to be redirected to the profile.
> 2. The profile shows one’s info like full name, role, etc.
> 3. User is taken to the account creation page.
> 4. Admin can click on delete and be redirected back to the accounts list.
> 5. The deleted member should not be shown in the list.

### US 2.08 - Admin edit their own account
> **As** an admin, **I want** to change my own account information, **so that** I can update my information to the system.

> **Acceptance Tests**

> 1. Make sure there is a button to edit within the profile.
> 2. The account then can be edited.
> 3. The new information should pass the field checks; otherwise, error messages.
> 4. New data is updated in the database.
> 5. For testing, check the same profile to see whether changes on have been updated.

### US 2.09 - Admin leave his/her account
> **As** an admin, **I want** to log out from current account, **so that** I can keep my account safe or switch to another account.

> **Acceptance Tests**

> 1. Make sure there is a button to log out.
> 2. After log out, the admin should be back to the user sign in page.
> 3. Once the admin is logged out, the admin no longer has the access to the system until he/she logs back in.

### US 2.10 - Admin can register their own organization
> **As** an admin, **I want** to register my organization, **so that** I can invite my organization members to take the assessment I created.

> **Acceptance Tests**

> 1. Make sure there are text fields for the admin to enter the organization name, organization description.
> 2. There should be a button where admin can finalize the information they enter and submit their information
> 3. As a result, an access code should be generated and shown to the admin after the organization is created.
> 4. For checking, the admin should be able to see the organization he/she just created.


### US 2.11 - Admin can sign them up
> **As** an Admin, **I want** to register myself into the system, **so that** I can manage my organization.

> **Acceptance Tests**

> 1. Sign Up with correct information
> 2. Any inputs that don't satisfy the field checks would result in error message.
> 3. After successfully signing up, the admin can log in his/her account to see whether their account has been signed up.

### US 2.12 - Admin can log in
> **As** an Admin, **I want** to log into my account, **so that** I can get access to my assessment.

> **Acceptance Tests**

> 1. Login as user with correct information.
> 2. Any inputs that don't satisfy the field checks would result in error message.
> 3. If the admin logs in successfully, then admin is then redirected to homepage.

### US 2.13 - Admin can edit the assessment’s answer
> **As** an admin, **I want** to edit my assessment’s answers, **so that** I can adjust my assessment.

> **Acceptance Tests**

> 1. There is a submit button to save the changes made
> 2. There is a cancel button to cancel the changes made.
> 3. Any changes will be updating the database.
> 4. For testing, admin can view the assessment to see whether the changes on the assessment's answer(s) have been updated

### III. EFCL ADMIN
### US 3.01 - EFCL Admin can see the organization lists
> **As** an admin, **I want** to view the list of all organizations that have signed them up into the system, **so that** I can keep track of who is utilizing the assessment tool.

> **Acceptance Tests**

> 1. Admin should be able to see the list of all organizations registered.

### US 3.02 - EFCL Admin can see the organization’s result.
> **As** an Admin, **I want** to see the result of any organization, **so that** I can understand the financial trends of all the registered organizations and compare them.
> 
> **Acceptance Tests**
> 
> 1. Admin should see the list of all organizations which shows the each organization’s result.

### US 3.03 - EFCL Admin log out his/her account
> **As** an EFCL Admin, **I want** to log out from current account, **so that** I can keep my account safe or switch to another account.
> 
>**Acceptance Tests**
>
> 1. Make sure there is a button to log out.
> 2. After log out, the admin should be back to the user sign in page.
> 3. Once the EFCL admin is logged out, the EFCL admin no longer has the access to the system until he/she logs back in.

### US 3.04 - EFCL Admin can log in
> **As** an EFCL Admin, **I want** to log into my account, **so that** I can get access to my assessment

> **Acceptance Tests**

> 1. Login as user with correct information.
> 2. Any inputs that don't satisfy the field checks would result in error message.
> 3. If the EFCL admin logs in successfully, then EFCL admin is then redirected to homepage.

### US 3.05 - EFCL Admin can sign them up
> **As** an Admin, **I want** to register myself into the system, **so that** I can manage my organization.

> **Acceptance Tests**

> 1. Sign Up with correct information
> 2. Any inputs that don't satisfy the field checks would result in error message.
> 3. After successfully signing up, the EFCL admin can log in his/her account to see whether their account has been signed up.

### US 3.06 - EFCL Admin can edit the questions universally
> **As** an EFCL Admin, **I want** to edit the questions for everyone, **so that** the questions can guarantee accuracy over time.

> **Acceptance Tests**
> 1. There is a submit button to save the changes made
> 2. There is a cancel button to cancel the changes made.
> 3. Any changes will be updating the database.
> 4. For testing, the EFCL admin should be able to see the assessment's questions being changed once he/she clicked onto the assessment he/she just edited.


### IV. BOARD MEMBER
### US 4.01 - Board members start the assessments
> **As** a Board Member, **I want** to see the assessment of my organization, **so that** I can start my assessment.

> **Acceptance Tests**

> 1. I cannot see the assessment until my admin finishes it.
> 2. I can click on and start the assessment.
> 3. I can only do the assessment within the time limit( 30’-1h) (countdown started once pulling up the assessment)
> 4. Once the assessment has been started, I am now redirected to the assessment page.

### US 4.02 - Board Members finish the assessment
> **As** a board member, **I want** to type/click the answers for my assessment, **so that** I can finish the assessment and be ready for sending.

> **Acceptance Tests**

> 1. Members can hit the submit button after finishing.
> 1.1 Error message if any field is left blank.
> 2. Board members should be able to click for the multiple choice questions and T/F questions.
> 3. For testing, board members should be able to see the answers selected once the entered their answers on the questions they were working on.

### US 4.03 - Board Members review the assessment
> **As** a board member, **I want** to review my answers for my assessment, **so that** I can fix any error before submitting.

> **Acceptance Tests**

> 1. Members can view the review of their responses.
> 2. Members can click the confirm button or go back to change the response.

### U.S 4.04 - Board Members submit the assessment
> **As** a board member, **I want** to confirm submission after reviewing, **so that** I can send my response to be graded.

> **Acceptance Tests**

> 1. Members can hit the confirm button after reviewing.
> 2. Data is saved to the database.
> 3. Members are redirected back to the dashboard.


### US 4.05 - Board Members get graded
> **As** a board member, **I want** to my assessment to be graded, **so that** I can see my score and the percentage.

> **Acceptance Tests**

> 1. The member's assessment is compared to the admin's solutions to be graded.

### U.S 4.06 - Board Members see scores
> **As** a Board Members, **I want** to check my result and organizational score, **so that** I can see where I am within my organization.
> 
> **Acceptance Tests**

> 1. Board members shoudl be able to see their own score and the current average score of the organization.
> 2. Optional: marks distribution.

### US 4.07 - Board members quit the assessment
> **As** a board member, **I want** to have a button that I can quit the assessment that I was working on, **so that** I can quit my assessment.

> **Acceptance Tests**

> 1. Members can quit the assessment by going back to the dashboard or closing the window.
> 2. The countdown timer is still on.
> 3. Once the members had quitted the assessment, they can no longer access the assessment and redirected to the previous page.
> 4. Members can always go back to continue within the time limit.
> 5. After that, members can only see their graded results.

### U.S 4.08 - Board Members get feedback
> **As** a board member, **I want** to get feedback or advice based on my result, **so that** I can know what financial practice I do to improve the organization.

> **Acceptance Tests**

> 1. For testing, board members should get feedback based on their own scores.


### US 4.09 - Board members edit their own account
> **As** a Board Member, **I want** to change my own account information, **so that** I can update my information to the system

> **Acceptance Tests**

> 1. Make sure there is a button to edit within the profile
> 2. The account then can be edited.
> 3. The new information should pass the field checks; otherwise, error messages.
> 4. New data is updated in the database.
> 5. For testing, board members can view their own profile to ensure the changes have been applied.

### US 4.10 - Board members leave his/her account
> **As** a board member , **I want** to log out from current account, **so that** I can keep my account safe or switch to another account.

> **Acceptance Tests**

> 1. Make sure there is a button to log out.
> 2. After log out, the board member should be back to the user sign in page.

### US 4.11 - Board members can log in to their domain
> **As** a board member , **I want** to be able to log into my organization domain, **so that** I can take my organization’s assessment.

>**Acceptance Tests**

> 1. Board members can enter the access code for their organization. 
> 1.1 Error message if user inputs non-existing/ incorrect access code
> 2. If the board members log in to their accounts successfully, then board members are then taken to the account creation page.


### US 4.12 - Authentication- create an account
>**As** a board member, **I want** to create an account, **so that** I can log in and get access to the survey of my organization.

> **Acceptance Tests**

> 1. Board members enter their required information like name, email, password, role at organization.
> 1.1. Error message if any field does not pass field check.
> 2. Board members clicks sign-up button 
> 2.2. Error message if the email is already in use.
> 3. Data is saved in the database.
> 4. Board members are then redirected to the log-in page.
> 5. For testing, board members shoudl be able to log in to the account that they had just created.

### US 4.13 - Authentication- log in an account
>**As** a board member, **I want** to log in to my account, **so that** I can take the survey of my organization.

> **Acceptance Tests**
> 1. Board members input their email and password 
> 1.1. Error message if they got any of the email or password wrong.
> 2. Board members will be redirected to the homepage




## MoSCoW

### Must Have
* US 1.01 - Two types of assessment
* US 1.02 - Grade members' assessments
* US 2.01 - Admin can see the organization’s access code
* US 2.02 - Admin can start the assessment
* US 2.03 - Admin can finish the assessment
* US 2.04 - Admin view the results
* US 2.05 - Admin export results
* US 2.10 - Admin can register their own organization
* US 2.11 - Admin can sign them up
* US 2.12 - Admin can log in
* US 3.01 - EFCL Admin can see the organization lists
* US 3.02 - EFCL Admin can see the organization’s result
* US 3.04 - EFCL Admin can log in
* US 3.05 - EFCL Admin can sign them up
* US 4.01 - Board Members can start the assessment
* US 4.02 - Board Members finish the assessment
* US 4.04 - Board Members submit the assessment
* US 4.05 - Board Members get graded
* US 4.06 - Board members check the result
* US 4.09 - Board members edit their own account
* US 4.10 - Board members leave his/her account
* US 4.11 - Board members can log in to their domain
* US 4.12 - Authentication- create an account
* US 4.13 - Authentication- log in an account

### Should Have
* US 2.09 - Admin leave his/her account
* US 3.03 - EFCL Admin leave his/her account
* US 4.03 - Board Members review the assessment
* US 3.06 - EFCL Admin can edit the questions universally

### Could Have
* US 2.06 - Admin view the members’ accounts list
* US 2.07 - Admin can view a member's profile
* US 2.08 - Admin edit their own account
* US 4.08 - Board Members get feedback
* US 4.07 - Board members quit the assessment

### Would Like But Won't Get
* US 2.13 - Admin can edit the assessment’s answer


## Similar Products
* [Google Forms](https://www.google.ca/forms/about/)
	- Web-based survey that allows users to create questions in any form- written response, or with radio buttons/ check boxes.
	- Constantly saves the answers to the cloud and allows respondents to close the survey at any time.
	- Allows conductors to get the overview of results.
	- This helps enable our envision on user interface and "syncing work" functionality.

* [Wufoo](https://www.wufoo.com/home/?utm_bu=wufoo&utm_campaign=20_Wufoo_WF_BR_CA_EN_Core_Exact_X&utm_content=WF_BR_CA_EN_Core_X&utm_medium=c&utm_source=google&utm_term=wufoo&utm_kxconfid=s4bvpi0ju&gclid=Cj0KCQjwv5uKBhD6ARIsAGv9a-z6S7SpB-8fBIyxD4OcZ1MQ5L2HqulI8eQzp1CEis-Qw0ouKMe0xzsaApbbEALw_wcB&gclsrc=aw.ds)
	- Online form builder that assists collecting data, payments and automating workflows.
	- Users can create different kinds of forms using pre-built drag-drop-question templates or even start from scratch.
	- The data is always in sync with the Cloud Storage Database.
	- The "collecting data" that aggregates the data collected then process it can be a good reference for this project.


## Open-source Projects
* [QuizMe](https://github.com/RobBednark/quiz-me)
	- Allows users to create and take quiz-like questionnaires.
	- Support various types of question choices like multiple choice, check-boxes, and written answers, etc.
	- Built using Django and PostgreSQL.
	- We might learn more on how to make different styles of questions and how they "set" the solutions for assessments.

## Techincal Resources
### Backend: Django + PostgreSQL
* [Django REST framework Documentation](https://www.django-rest-framework.org/)
* [Setting up Postgres](https://postgresapp.com/)

### Frontend: ReactJS
* [React Tutorial](https://reactjs.org/tutorial/tutorial.html)

### Deployment: Cybera + Docker + TravisCI
* [Cybera Rapid Access Cloud Tutorial Screencast](https://www.youtube.com/watch?v=jv4D8I_AwTQ)
* [Docker Orientation and Setup](https://docs.docker.com/get-started/)
* [Documentation on GitHub Actions](https://docs.github.com/en/actions)
